<?php
class Transaction_model extends CI_Model
{

    public $table_name = "transactions";

    public $userId;
    public $amount;
    public $transType;
    public $transRefNo;
    public $transRefDoc;
    public $createdAt;
    public $updatedAt;
    public $createdBy;
    public $updatedBy;
    public $status;

    public function createTransaction($data)
    {
        
        $insertData = [
            'createdAt' => date('Y-m-d h:i:s'),
        ];
        
        if (array_key_exists('amount', $data))
            $insertData['amount'] = $data['amount'];
        if (array_key_exists('status', $data))
            $insertData['status'] = $data['status'];
        if (array_key_exists('transRefNo', $data))
            $insertData['transRefNo'] = $data['transRefNo'];
        if (array_key_exists('transRefDoc', $data))
            $insertData['transRefDoc'] = $data['transRefDoc'];
        if (array_key_exists('userId', $data)) {
            $insertData['userId'] = $data['userId'];
            $insertData['createdBy'] = $data['userId'];
        }
        if (array_key_exists('transType', $data))
            $insertData['transType'] = $data['transType'];
        $this->db->insert($this->table_name, $insertData);
    }

    public function updateTransection($userId,$data)
    {
        $insertData=[];
        if (array_key_exists('amount', $data))
        $insertData['amount'] = $data['amount'];
    if (array_key_exists('transRefNo', $data))
        $insertData['transRefNo'] = $data['transRefNo'];
    if (array_key_exists('transRefDoc', $data))
        $insertData['transRefDoc'] = $data['transRefDoc'];
        $this->db->from($this->table_name)
        ->where('id',$userId)
        ->set(
            $insertData
        )
        ->update();
    }
    
     public function userRegistrationStatusUpdate($userId, $status)
    {
        try {
            $updateData =  [
                'status' => $status,
                'updatedAt' => date('Y-m-d h:i:s'),
                'updatedBy' => $this->session->userdata('userId')
            ];


            $this->db->from($this->table_name)
                ->where('userId', $userId)
                ->set(
                    $updateData
                )
                ->update();
        } catch (Exception $e) {
            print_r($e);
        }
    }
    
    

    public function historyDeails($role, $userId)
    {

        if ($role == "vendor") {
            $this->db->select('*')
                ->from($this->table_name)
                ->where('userId', $userId);
            $data = $this->db->get();
            return $data->result();
            
        } else {
            $this->db->select('*')
                ->from('users')
                ->join('transactions','transactions.userId = users.id' , 'left')
                ->where('transactions.transType','deposite');
            $data = $this->db->get();
            // print_r($data->result());die;
            return $data->result();
        }
    }
    
    public function getUser($username)
    {
      
        $query = $this->db->select('*')
            ->from('users')
            ->join('transactions','transactions.userId = users.id' , 'right')
            ->where('transactions.id', $username)
            ->get();
        return $query->result();
    }
    public function userPaymentStatusUpdate($userId, $status)
    {
        try {
            $updateData =  [
                'status' => $status,
                'updatedAt' => date('Y-m-d h:i:s'),
                'updatedBy' => $this->session->userdata('userId')
            ];

            $this->db->from($this->table_name)
                ->where('id', $userId)
                ->set(
                    $updateData
                )
                ->update();
        } catch (Exception $e) {
            print_r($e);
        }
    }
}
