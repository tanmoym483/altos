<?php
class Dashbord_model extends CI_Model
{
    public $table_name = "users";
   

   
public function totalMembar(){
      $resp="SELECT u.*, p.firstName as par_firstName, p.regId as par_reg_id, lc.firstName as left_child_firstName, rc.firstName as right_child_firstName
        FROM `users` u 
        LEFT JOIN users p ON p.id = u.parentNode
        LEFT JOIN users lc on lc.id = u.leftChild 
        LEFT JOIN users rc on rc.id = u.rightChild 
         where u.status='active'";
            //  where u.firstName='$search'";
             $query = $this->db->query($resp);
             return $query->num_rows();
}
    
}
