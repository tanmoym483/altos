<?php
class Admin_model extends CI_Model
{
    public $table_name = "m_states";
   

    public $state;
    public $district;
    public $pincode;
    
    public function postalCodeDetails($data){
        $this->db->select('*')
        ->from('m_states')
        ->where('pincode',$data);
        $data=$this->db->get();
        $response=$data->result();
        return $response;
    }

    public function addPostalCode($data){
        $pincode=$data['pincode'];
        $this->db->select("*")
        ->from('m_states')
        ->where('pincode',$pincode);
       $res=$this->db->get();
       if($res){
           
       }else{
            $insertData =[];
        if (array_key_exists('state', $data))
            $insertData['state'] = $data['state'];
        if (array_key_exists('district', $data))
            $insertData['district'] = $data['district'];
        if (array_key_exists('pincode', $data))
            $insertData['pincode'] = $data['pincode'];
            $this->db->insert($this->table_name, $insertData);
       }
    }
    
}
